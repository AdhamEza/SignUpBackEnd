const express = require('express')
const router = express.Router()
const signUpTemplateCopy = require('../models/SignUpModels')
const bcrypt = require('bcrypt')
const jwt=require("jsonwebtoken")

const JWT_SECRET=
"hvdvay6ert72839289()aiyg8t87qt72393293883uhefiuh78ttq3ifi78272jbkj?[]]pou89ywe";


router.post('/signup', async (request, response) => {

    const saltPassword = await bcrypt.genSalt(10)
    const securePassword = await bcrypt.hash(request.body.password, saltPassword)


    const signedUpUser = new signUpTemplateCopy({
        fullName: request.body.fullName,
        username: request.body.username,
        email: request.body.email,
        password: securePassword
    })
    signedUpUser.save()
        .then(data => {
            response.json(data)
            
        })
        .catch(error => {
            response.json(error)
        })

       
})
router.post('/signin', async (request, response) => {
    const {email,password} = req.body;
    
    const user = await signedUpUser.findOne({ email });
    if(!user){
        return response.json({error:"User not found"});
    }
    if(await bcrypt.compare(password,user.password)){
        const token = jwt.sign({},JWT_SECRET);
        if(response.status(201)){
            return response.json({status:"ok",data:token});
        } else {
            return response.json({error:"error"});
        }
    }
    response.json({status:"error",error:"Invalid Password"});
    })

module.exports = router